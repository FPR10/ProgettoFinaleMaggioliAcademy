import { Routes } from '@angular/router';
export const routes: Routes = [
  { path: '', pathMatch: 'full', loadComponent: () => import('./features/anagrafiche/anagrafica-list').then(m => m.AnagraficaList) },
  { path: 'anagrafiche/nuova', loadComponent: () => import('./features/anagrafiche/anagrafica-form').then(m => m.AnagraficaForm) },
  { path: 'anagrafiche/:id/modifica', loadComponent: () => import('./features/anagrafiche/anagrafica-form').then(m => m.AnagraficaForm) },
  { path: '**', redirectTo: '' }
];
