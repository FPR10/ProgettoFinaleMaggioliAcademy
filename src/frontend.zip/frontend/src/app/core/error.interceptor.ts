import { inject } from '@angular/core';
import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { NotificationService } from './notification.service';

export const errorInterceptor: HttpInterceptorFn = (request, next) => {
  const notifications = inject(NotificationService);
  return next(request).pipe(catchError((error: HttpErrorResponse) => {
    if (error.status === 0) notifications.show('Backend non raggiungibile');
    else if (error.status >= 500) notifications.show(`Errore del server (${error.status})`);
    return throwError(() => error);
  }));
};
